package com.infy.ekart.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

//import com.infy.ekart.api.DealsForTodayAPI;
import com.infy.ekart.dto.DealsForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealsForToday;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.DealsForTodayRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;


@Service
@Transactional
public class DealsForTodayServiceImpl implements DealsForTodayService{ //Need to be Implemented.ss
	
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private SellerRepository sellerRepository;
	@Autowired
	private DealsForTodayRepository dealsForTodayRepository;
	

	@Override
	public List<ProductDTO> getProductsWithoutDeals(String sellerEmailId, Integer pageNo) throws EKartException {
		
		Pageable p = PageRequest.of(pageNo, 10);
		
		List<Product> productList = dealsForTodayRepository.productsWithoutDealsForToday(sellerEmailId, p);
		List<ProductDTO> productDTOs = new ArrayList<>();
		if(productList == null || productList.isEmpty()) {
			throw new EKartException("DealsForToday.PRODUCTS_NOT_FOUND");
		}
		
		for(Product product: productList)
		{
			ProductDTO productDTO = new ProductDTO();
			productDTO.setBrand(product.getBrand());
			productDTO.setCategory(product.getCategory());
			productDTO.setDescription(product.getDescription());
			productDTO.setDiscount(product.getDiscount());
			productDTO.setName(product.getName());
			productDTO.setProductId(product.getProductId());
			productDTO.setQuantity(product.getQuantity());
			productDTO.setPrice(product.getPrice());
			productDTO.setSellerEmailId(sellerEmailId);
			productDTOs.add(productDTO);
		}
		return productDTOs;
	}

		@Override
		public Integer addProductsToDealsForToday(DealsForTodayDTO dealsForTodayDTO) throws EKartException {
			
			
			Optional<Product> optional = productRepository.findById(dealsForTodayDTO.getProductDTO().getProductId());
			Product product = optional.orElseThrow(()->new EKartException("Service.PRODUCT_NOT_FOUND"));
			Optional<Seller> optional1 = sellerRepository.findById(dealsForTodayDTO.getSellerDTO().getEmailId());
			Seller seller = optional1.orElseThrow(()->new EKartException("Service.SELLER_NOT_FOUND"));
			if(!(dealsForTodayDTO.getStartDate().toLocalDate().isEqual(dealsForTodayDTO.getEndDate().toLocalDate()) && 
					ChronoUnit.DAYS.between(LocalDate.now(), dealsForTodayDTO.getStartDate().toLocalDate())<30 && 
					dealsForTodayDTO.getEndDate().isAfter(dealsForTodayDTO.getStartDate()))) {
				throw new EKartException("DealsForToday.INVALID_DETAILS");
			}

			
			DealsForToday dealForToday = new DealsForToday();
			dealForToday.setDealDiscount(dealsForTodayDTO.getDealDiscount());
			dealForToday.setEndDate(dealsForTodayDTO.getEndDate());
			dealForToday.setStartDate(dealsForTodayDTO.getStartDate());
			dealForToday.setSeller(seller);
			dealForToday.setProduct(product);
			
			dealsForTodayRepository.save(dealForToday);
			return dealForToday.getDealId();
		}
		

		
		@Override
		public Integer removeProductFromDeals(Integer dealId) throws EKartException{
			
			
			Optional<DealsForToday> optional = dealsForTodayRepository.findById(dealId);
			DealsForToday expiredDeal= optional.orElseThrow(()->new EKartException("DealsForToday.NO_DEALS_FOUND"));
			expiredDeal.setSeller(null);
			expiredDeal.setProduct(null);
			Integer id= expiredDeal.getDealId();
			dealsForTodayRepository.delete(expiredDeal);
			return id;
		}

		
		public List<DealsForTodayDTO> viewSellerDealsForToday(String sellerEmailId,Integer pageNo) throws EKartException{
			Pageable p=PageRequest.of(pageNo, 10);
			List<DealsForToday> list = dealsForTodayRepository.findBySellerEmailId(sellerEmailId,p);
			List<DealsForTodayDTO> dealsForTodayDTOs = new ArrayList<>();
			if(list == null || list.isEmpty())
				throw new EKartException("DealsForToday.NO_PRODUCTS_ON_DEAL");
			for(DealsForToday dealsForToday: list) {
				DealsForTodayDTO dto = new DealsForTodayDTO();
				dto.setDealDiscount(dealsForToday.getDealDiscount());
				dto.setDealId(dealsForToday.getDealId());
				dto.setEndDate(dealsForToday.getEndDate());
				dto.setStartDate(dealsForToday.getStartDate());
				
				ProductDTO productDTO = new ProductDTO();
				productDTO.setBrand(dealsForToday.getProduct().getBrand());
				productDTO.setCategory(dealsForToday.getProduct().getCategory());
				productDTO.setDescription(dealsForToday.getProduct().getDescription());
				productDTO.setDiscount(dealsForToday.getProduct().getDiscount());
				productDTO.setQuantity(dealsForToday.getProduct().getQuantity());
				productDTO.setSellerEmailId(dealsForToday.getProduct().getEmailId());
				productDTO.setErrorMessage("Error");
				productDTO.setName(dealsForToday.getProduct().getName());
				productDTO.setPrice(dealsForToday.getProduct().getPrice());
				productDTO.setProductId(dealsForToday.getProduct().getProductId());
				productDTO.setSuccessMessage("Success");
				dto.setProductDTO(productDTO);
				
				SellerDTO sellerDTO = new SellerDTO();
				sellerDTO.setName(dealsForToday.getSeller().getName());
				sellerDTO.setAddress(dealsForToday.getSeller().getAddress());
				sellerDTO.setPhoneNumber(dealsForToday.getSeller().getPhoneNumber());
				sellerDTO.setErrorMessage("Error");
				sellerDTO.setEmailId(dealsForToday.getSeller().getEmailId());
				dto.setSellerDTO(sellerDTO);
				
				dealsForTodayDTOs.add(dto);			
				}
			return dealsForTodayDTOs;
		}
		
		@Override
		public List<DealsForTodayDTO> getDealsForToday(Integer pageNo) throws EKartException{
			LocalDateTime start = LocalDateTime.of(LocalDate.now(), LocalTime.of(0, 0, 0));
			LocalDateTime end = LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(0, 0, 0));
			Pageable p = PageRequest.of(pageNo, 10);
			
			List<DealsForToday> dealsList = dealsForTodayRepository.customerDealsForToday(start, end, p);
			List<DealsForTodayDTO> dtos = new ArrayList<>();
			if(dealsList == null || dealsList.isEmpty())
				throw new EKartException("DealsForToday.NO_DEALS_FOUND");
			for(DealsForToday deals:dealsList) {
				DealsForTodayDTO dto = new DealsForTodayDTO();
				dto.setDealDiscount(deals.getDealDiscount());
				dto.setDealId(deals.getDealId());
				dto.setEndDate(deals.getEndDate());
				dto.setStartDate(deals.getStartDate());
				
				
				ProductDTO productDTO = new ProductDTO();
				productDTO.setBrand(deals.getProduct().getBrand());
				productDTO.setCategory(deals.getProduct().getCategory());
				productDTO.setDescription(deals.getProduct().getDescription());
				productDTO.setDiscount(deals.getProduct().getDiscount());
				productDTO.setErrorMessage("Error");
				productDTO.setName(deals.getProduct().getName());
				productDTO.setPrice(deals.getProduct().getPrice());
				productDTO.setProductId(deals.getProduct().getProductId());
				productDTO.setSuccessMessage("Success");
				productDTO.setSellerEmailId(deals.getProduct().getEmailId());
				dto.setProductDTO(productDTO);
				
				SellerDTO sellerDTO = new SellerDTO();
				sellerDTO.setName(deals.getSeller().getName());
				sellerDTO.setAddress(deals.getSeller().getAddress());
				sellerDTO.setPhoneNumber(deals.getSeller().getPhoneNumber());
				sellerDTO.setErrorMessage("Error");
				sellerDTO.setEmailId(deals.getSeller().getEmailId());
				dto.setSellerDTO(sellerDTO);
				
				dtos.add(dto);	
			}
			return dtos;
		}
		
	
}
