
package com.infy.ekart.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;;

@Entity
@Table(name = "EK_DEALS_FOR_TODAY")
public class DealsForToday {
	
	@Id
	@Column(name="DEAL_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private Integer dealId;
	
	
	@Column(name="DEAL_DISCOUNT")
	private Double dealDiscount;
	
	@Column(name="DEAL_STARTS_AT")
	private LocalDateTime startDate;
	
	@Column(name="DEAL_ENDS_AT")
	private LocalDateTime endDate;
	
	@OneToOne(cascade = CascadeType.ALL)	
	@JoinColumn(name="PRODUCT_ID")
	private Product product;
 
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "SELLER_EMAIL_ID")
	private Seller seller;
	

	public Integer getDealId() {
		return dealId;
	}
	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}
	

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	

	public Double getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(Double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}
	public LocalDateTime getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}
	public LocalDateTime getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	

}
	