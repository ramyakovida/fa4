import { TestBed } from '@angular/core/testing';

import { ViewDealsForTodayService } from './view-deals-for-today.service';

describe('ViewDealsForTodayService', () => {
  let service: ViewDealsForTodayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewDealsForTodayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
