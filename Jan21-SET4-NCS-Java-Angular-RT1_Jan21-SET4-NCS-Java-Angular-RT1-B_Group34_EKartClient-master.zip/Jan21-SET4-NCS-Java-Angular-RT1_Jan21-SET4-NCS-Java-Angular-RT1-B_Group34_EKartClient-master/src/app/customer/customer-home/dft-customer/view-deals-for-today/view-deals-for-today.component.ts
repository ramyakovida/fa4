  
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { DealsForToday } from 'src/app/shared/models/deals';
import { ViewDealsForTodayService } from './view-deals-for-today.service';
import { ViewAllProductsService } from '../../view-all-products/view-all-products.service';



@Component({
  selector: 'app-view-deals-for-today',
  templateUrl: './view-deals-for-today.component.html',
  styleUrls: ['./view-deals-for-today.component.css']
})
export class ViewDealsForTodayComponent implements OnInit {

  p: number = 0;
  page: boolean = false;
  isProductSelected: boolean = false;
  selectedProduct: Product;
  productOnDeals: DealsForToday[] = [];
  count: number = 0;
  errorMessage: string;
  successMessage: string;
  now = new Date();
  status: number[];
  pageLength: number;
  startDateTime: Date;
  endDateTime: Date;

  constructor(private viewDealsForTodayService: ViewDealsForTodayService, private viewAllProductSerevices: ViewAllProductsService) {
    setInterval(() => {
      this.now = new Date();
      this.setStatus();
    }
      ,5000);
   }

  ngOnInit(): void {
    this.successMessage = null;
    this.errorMessage = null;
    this.productOnDeals = null;

    this.getProductOnDealsForCustomer();
  }
  getProductOnDealsForCustomer(){
    this.status = [];

    this.viewDealsForTodayService.getDealsForToday(this.p).subscribe(
      (response)=>{
        console.log(response);

      this.viewAllProductSerevices.getAllProducts().subscribe(
        products=> {
          let temp=[];
          for(let i=0;i<products.length;i++){
            for(let j=0;j<response.length;j++){
              if(products[i].productId==response[j].productDTO.productId){
                temp.push({
                  dealId: response[j].dealId,
                  productDTO: products[i],
                  dealDiscount: response[j].dealDiscount,
                  startDate: response[j].startDate,
                  endDate: response[j].endDate,
                  sellerDTO: response[j].sellerDTO,
                  errorMessage: response[j].errorMessage,
                  successMessage: response[j].successMessage
                });
              }
            }
          }
          this.productOnDeals=temp;
          console.log(this.productOnDeals)
          this.setStatus();
        }
      );
      },
      (response)=>{
        this.errorMessage=<any>response;
        this.productOnDeals=null;
        this.successMessage=null;
      }
    )
  }

  setStatus(){
    let currTime=this.now;

    this.count=0;
    //this.productOnDeals=[];
    for(var i=0;i<this.productOnDeals.length;i++){
      this.startDateTime = new Date(this.productOnDeals[i].startDate[0],
        this.productOnDeals[i].startDate[1] - 1,
        this.productOnDeals[i].startDate[2],
        this.productOnDeals[i].startDate[3],
        this.productOnDeals[i].startDate[4],
        0);

      this.endDateTime = new Date(this.productOnDeals[i].endDate[0],
        this.productOnDeals[i].endDate[1] - 1,
        this.productOnDeals[i].endDate[2],
        this.productOnDeals[i].endDate[3],
        this.productOnDeals[i].endDate[4],
        0);

        if(this.startDateTime.getTime()<currTime.getTime() && this.endDateTime.getTime()>currTime.getTime()){
          this.status[i]=1;
          this.count++
        }
        else if(this.startDateTime.getTime()>currTime.getTime()){
          this.status[i]=2;
        }
        else if(this.endDateTime.getTime(),currTime.getTime()){
          this.status[i]=3;
        }

    }
  }

  setSelectedProduct(product: Product){
    this.isProductSelected=true;
    this.successMessage=null;
    this.selectedProduct=product;
    console.log(product)
    console.log(this.selectedProduct)
  }

  unsetSelectedProduct(product: Product){
    this.isProductSelected=false;
    this.selectedProduct=null;
  }
  goToPrevious(){

    if(this.p>0){
      this.p--
      this.getProductOnDealsForCustomer();
      this.page=false
    }
  }

  goToNext(){

    if(this.productOnDeals.length==10){
      this.p++
      this.getProductOnDealsForCustomer();
    }
    else{
      this.page=true;
    }
  }

}