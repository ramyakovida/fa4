import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/shared/models/product';

@Component({
  selector: 'app-view-selected-deal',
  templateUrl: './view-selected-deal.component.html',
  styleUrls: ['./view-selected-deal.component.css']
})
export class ViewSelectedDealComponent implements OnInit {
  @Input() selectedProduct: Product;
  constructor() {
    console.log(this.selectedProduct)
  }

  ngOnInit() {
  }
  ndOnDestroy(){
    Object.assign(this.selectedProduct);
  }
  

}