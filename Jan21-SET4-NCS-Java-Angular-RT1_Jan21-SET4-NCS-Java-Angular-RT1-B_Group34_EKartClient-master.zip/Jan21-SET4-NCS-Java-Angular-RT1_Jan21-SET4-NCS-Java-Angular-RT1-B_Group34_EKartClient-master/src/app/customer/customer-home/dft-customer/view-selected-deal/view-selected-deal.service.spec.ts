import { TestBed } from '@angular/core/testing';

import { ViewSelectedDealService } from './view-selected-deal.service';

describe('ViewSelectedDealService', () => {
  let service: ViewSelectedDealService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewSelectedDealService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
