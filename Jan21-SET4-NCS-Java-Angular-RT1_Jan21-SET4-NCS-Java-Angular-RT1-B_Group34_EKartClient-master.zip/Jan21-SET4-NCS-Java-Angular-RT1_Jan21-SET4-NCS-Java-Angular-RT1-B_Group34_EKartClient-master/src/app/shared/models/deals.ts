import { Product } from './product';
import {Time} from '@angular/common';
import { Seller } from './seller';
export class DealsForToday{
    dealId:number;
    productDTO:Product;
    dealDiscount: number;
    startDate:Date;
    endDate:Date;
    sellerDTO:Seller;
    errorMessage: String;
    successMessage: string;
}