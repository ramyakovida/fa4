import { Component, OnInit, Input } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { DealsForToday } from 'src/app/shared/models/deals';
import { DftSellerViewProductsService } from './dft-seller-view-products.service';
import { Product } from 'src/app/shared/models/product';

@Component({
  selector: 'app-dft-seller-view-products',
  templateUrl: './dft-seller-view-products.component.html',
  styleUrls: ['./dft-seller-view-products.component.css']
})
export class DftSellerViewProductsComponent implements OnInit {

seller:Seller;
p:number=0;
page:Boolean;
dealsForTodayList:DealsForToday[];
addedDeal:DealsForToday;
showDeal:boolean=false;
display:boolean=true;
successMessage:any;
errorMessage:string;
dealsListLength:number;


 @Input()
receivedproduct:Product;
 productList:Product[]
 deal:DealsForToday
  displayProducts:Boolean
  productsAvailable :Boolean
productInDeal:DealsForToday[]=[];
 productDetails:Product;


  constructor(private dealService:DftSellerViewProductsService) { }

  ngOnInit(): void {
    this.displayProducts=true;
    this.productList=JSON.parse(sessionStorage.getItem("seller"))
    this.seller=JSON.parse(sessionStorage.getItem("seller"));
    this.getDeals();
  }
    
removeFromDeals(deal:DealsForToday){
  this.successMessage=null;
  this.errorMessage=null;

  this.dealService.removeFromDeals(deal).subscribe(
    response => {
      this.successMessage = response;
      console.log(this.successMessage)
      this.getDeals();
    },
    response => {
      this.errorMessage = response;
      console.log(this.errorMessage)
      this.getDeals();
    }
  )

}

getDeals()
{
  this.page=true;
  this.dealService.getDeals(this.seller.emailId,this.p)
  .subscribe(response=>
    {
      this.dealsForTodayList=response
      this.displayProducts=this.dealsForTodayList.length!=0;
        this.page=this.dealsForTodayList.length!=10
      console.log(this.dealsForTodayList);
      
    })
}
setAddedDeal(deal:DealsForToday)
{
  
  this.showDeal=true;
  this.display=false;
  this.addedDeal=deal;

}

ifDealActive(productInDeal:DealsForToday): boolean{
  let systemTime:Date=new Date();
  let dealEndDate:Date= new Date(productInDeal.endDate[0],productInDeal.endDate[1]-1,productInDeal.endDate[2],
    productInDeal.endDate[3],productInDeal.endDate[4] ,0);
    if(dealEndDate<systemTime)
    {
      return false;
    }
    else
    return true;
}
viewProductDetails(productId:number)
{
this.productDetails=new Product;
for(let product of this.productList)
{
  if(productId==product.productId)
  {
    this.productDetails=product;
  }
}

}
tobackPage()
{
  this.display=true;
  this.showDeal=false;
}

toNextPage()
{
  
  this.p+=1;
  this.ngOnInit();
}
toPreviousPage()
{
  this.p-=1;
  this.ngOnInit();
}
}