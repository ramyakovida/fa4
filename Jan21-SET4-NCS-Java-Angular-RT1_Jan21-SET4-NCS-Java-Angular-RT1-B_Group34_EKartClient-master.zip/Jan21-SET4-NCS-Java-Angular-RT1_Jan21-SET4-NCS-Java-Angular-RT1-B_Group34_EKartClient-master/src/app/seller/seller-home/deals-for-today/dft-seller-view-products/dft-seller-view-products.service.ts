import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { DealsForToday } from 'src/app/shared/models/deals';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/internal/operators/catchError';
@Injectable({
  providedIn: 'root'
})
export class DftSellerViewProductsService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private httpClient:HttpClient) { }

getDeals(emailId,pageNo):Observable<DealsForToday[]>
{
  const url=environment.DealsForTodayAPIUrl+"/sellerDealsForToday"+"/"+emailId+"/"+pageNo
  return this.httpClient.get<DealsForToday[]>(url)
  .pipe(catchError(this.handleError));
}

removeFromDeals(dealId):Observable<any[]>{
  const url = environment.DealsForTodayAPIUrl + '/removeDeal' + '/'+dealId
   return this.httpClient.delete<any>(url,{headers : this.headers, responseType:'text' as 'json'})
   .pipe(catchError(this.handleError));
}

private handleError(err: HttpErrorResponse) {
  console.log(err)
  let errMsg: string = '';
  if (err.error instanceof Error) {
    errMsg = err.error.message;
    console.log(errMsg)
  }
  else if (typeof err.error === 'string') {
    errMsg = JSON.parse(err.error).errorMessage
  }
  else {
    if (err.status == 0) {
      errMsg = "A connection to back end can not be established.";
    } else {
      errMsg = err.error.message;
    }
  }
  return throwError(errMsg);
}
}