import { Component, OnInit,Input } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Product } from '../../../../shared/models/product';
import { DftSellerAddProductsService } from './dft-seller-add-products.service';
import { Seller } from '../../../../shared/models/seller';
import { IfStmt } from '@angular/compiler';
import { SellerProductsService } from '../../products/seller-products/seller-products.service';

@Component({
  selector: 'app-dft-seller-add-products',
  templateUrl: './dft-seller-add-products.component.html',
  styleUrls: ['./dft-seller-add-products.component.css']
})
export class DftSellerAddProductsComponent implements OnInit {

  
  seller: Seller
  successMessage: String="";
  errorMessage: string = "";
  productNotInDealList: Product[]
  p:number=0;
  page: boolean=false
  productToAdd:Product
  productAddForm: FormGroup
  displayProducts: Boolean
  submitted: Boolean
  productId: number
  dealStartsAt:string
  dealEndsAt:string
  sellerEmailId:string
  dealDiscount: number
  constructor(private formBuilder: FormBuilder, private dftSellerAddProductsService: DftSellerAddProductsService,
    private sellerService:SellerProductsService) { }

  ngOnInit():void {
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.productsCurrentlyBeingSold()

  }
  productsCurrentlyBeingSold(){
    this.dftSellerAddProductsService.productsCurrentlyBeingSold(this.seller.emailId, this.p)
      .subscribe(productNotInDealList => {
        this.productNotInDealList = productNotInDealList
        if(this.productNotInDealList.length >0){
          this.page=true
        }
        console.log(this.productNotInDealList)
        console.log(this.seller)
      
      })
      this.displayProducts = true
      this.submitted=false
  }
   
  add(product: Product){
    this.displayProducts = false
    this.submitted=true
    this.productToAdd=product
    this.sellerEmailId=this.seller.emailId
    console.log(this.sellerEmailId)

    this.productId = this.productToAdd.productId
    console.log(this.productId)
    this.successMessage=''
    this.errorMessage=''
    this.createForm()
    console.log(this.productToAdd)
  }

  createForm(){
    this.productAddForm=this.formBuilder.group({
      dealStartTime: ["",Validators.required],
      dealEndTime: ["",Validators.required],
      discount: ["",Validators.required]
    })
  }

  AddProductToDeal(){
    
    this.dealStartsAt=this.productAddForm.value.dealStartTime
    this.dealEndsAt=this.productAddForm.value.dealEndTime
    this.dealDiscount=this.productAddForm.value.discount
    
    
    this.dftSellerAddProductsService.addProductToDeal(this.productToAdd,this.dealDiscount,this.dealStartsAt,this.dealEndsAt, this.seller )
    .subscribe((response)=>{
      this.successMessage=response
      this.submitted=false
    
    },
    error => {
      this.errorMessage=<any>error 
    })
    
  } 
  goToPrevious(){
      if(this.p>0){
          this.p--
          this.productsCurrentlyBeingSold();
      }
  }
  goToNext(){
      if(this.productNotInDealList.length==10){
          this.p++
          this.productsCurrentlyBeingSold();
      }else{
          this.page=true;
      }
  }
}