import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { Product } from '../../../../shared/models/product';
import { environment } from '../../../../../environments/environment';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Seller } from 'src/app/shared/models/seller';

@Injectable({
  providedIn: 'root'
})
export class DftSellerAddProductsService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient) { }

  
 productsCurrentlyBeingSold(emailId: String, pageNo:number): Observable<Product[]> {
  const url = environment.DealsForTodayAPIUrl + "/withoutDeals" + "/"+emailId+"/"+pageNo;
  return this.http.get<Product[]>(url).pipe(catchError(this.handleError));
}


addProductToDeal(productDTO:Product, dealDiscount:number, startDate:string, endDate:string, sellerDTO:Seller): Observable<any> {
  const url = environment.DealsForTodayAPIUrl + "/addDeal";
  return this.http.post<any>(url, {productDTO, dealDiscount,startDate, endDate, sellerDTO}, { headers: this.headers, responseType: 'text' as 'json'})     
    .pipe(catchError(this.handleError));
}

  private handleError(err: HttpErrorResponse) {
    console.log(err)
    let errMsg: string = '';
    if (err.error instanceof Error) {
      errMsg = err.error.message;
      console.log(errMsg)
    }
    else if (typeof err.error === 'string') {
      errMsg = JSON.parse(err.error).errorMessage
    }
    else {
      if (err.status == 0) {
        errMsg = "A connection to back end cannot be established.";
      } else {
        errMsg = err.error.message;
      }
    }
    return throwError(errMsg);
  }
}